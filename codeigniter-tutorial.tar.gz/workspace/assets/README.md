# Boilerplate-a-mundo
A bare static page template that includes bootstrap 3, animate.css, font-awesome, and hover.css

This is just some nice boilerplate code to get your project going. Includes some neat libraries to get you on your way. 
